# Hidden Berkeley

## Purpose

Replace this paragraph with a short explanation of your intended audience and what this guide offers.

## Source

The eight entries come from the course file `data/hw2_hidden_berkeley_locations.csv`.
Each entry links to an official source. Readers should confirm current access details there.

## Project files

- `docs/index.md`: the page content, written in Markdown.
- `docs/_config.yml` and `docs/_layouts/default.html`: supplied display setup.

## Publish

In GitHub Settings → Pages, publish from the `main` branch and `/docs` folder.
After pushing, check the deployment status and open the actual site URL in a private browser window.

## Verification

Replace this paragraph with a brief note on what you actually checked on the published page.
