---
layout: default
title: Hidden Berkeley
---

# Hidden Berkeley

Write your two-sentence introduction here. Say who this guide is for and why readers should check the official sources.

## The supplied resources

### D-Lab

**Category:** methods support  
**Area:** Social Sciences Building  
**Access note:** Check the official site for current access details  
[Official source](<https://dlab.berkeley.edu/>)

### BAMPFA Film Library and Study Center

**Category:** media research  
**Area:** Downtown Berkeley  
**Access note:** Confirm appointments and access on the official site  
[Official source](<https://bampfa.org/>)

### Morrison Library

**Category:** quiet reading  
**Area:** Doe Library  
**Access note:** Library access policies can change  
[Official source](<https://www.lib.berkeley.edu/>)

### Jacobs Institute Makerspace

**Category:** prototyping  
**Area:** North campus  
**Access note:** Training may be required before equipment use  
[Official source](<https://jacobsinstitute.berkeley.edu/>)

### Basic Needs Center

**Category:** student support  
**Area:** UC Berkeley  
**Access note:** Use official pages for eligibility and hours  
[Official source](<https://basicneeds.berkeley.edu/>)

### Disabled Students' Program

**Category:** access support  
**Area:** UC Berkeley  
**Access note:** Do not publish private accommodation information  
[Official source](<https://dsp.berkeley.edu/>)

### Berkeley Art Museum and Pacific Film Archive

**Category:** arts and archives  
**Area:** Downtown Berkeley  
**Access note:** Admission and hours vary  
[Official source](<https://bampfa.org/>)

### UC Botanical Garden

**Category:** field observation  
**Area:** Strawberry Canyon  
**Access note:** Check current reservations and transit  
[Official source](<https://botanicalgarden.berkeley.edu/>)

---

Source: the course-provided public-resource catalog. Confirm current details using the official links.
